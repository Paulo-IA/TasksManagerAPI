﻿namespace TasksManager.Communication.Enums;

public enum Priority
{
    High,
    Medium,
    Low,
}
