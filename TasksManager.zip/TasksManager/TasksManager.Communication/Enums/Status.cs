﻿namespace TasksManager.Communication.Enums;

public enum Status
{
    Concluded,
    InProgress,
    Waiting
}
