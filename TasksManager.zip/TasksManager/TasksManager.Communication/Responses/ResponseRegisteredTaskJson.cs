﻿namespace TasksManager.Communication.Responses;

public class ResponseRegisteredTaskJson
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
}
