﻿namespace TasksManager.Communication.Responses;

public class ResponseErrosListJson
{
    public List<string> Errors { get; set; } = [];
}
