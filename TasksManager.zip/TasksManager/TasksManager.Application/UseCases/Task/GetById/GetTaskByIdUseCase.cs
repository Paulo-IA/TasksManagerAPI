﻿using TasksManager.Communication.Responses;

namespace TasksManager.Application.UseCases.Task.GetById;

public class GetTaskByIdUseCase
{
    public ResponseTaskJson Execute(int id)
    {
        return new ResponseTaskJson
        {
            Id = 1,
            Title = "Teste",
            Description = "Teste de descrição",
            LimitDate = new DateTime(year: 2024, month: 08, day: 25),
            Priority = Communication.Enums.Priority.Medium,
            Status = Communication.Enums.Status.Waiting,
        };
    }
}
