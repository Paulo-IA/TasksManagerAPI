﻿using TasksManager.Communication.Requests;

namespace TasksManager.Application.UseCases.Task.Update;

public class UpdateTaskUseCase
{
    public void Execute(int id, RequestTaskJson request)
    {
        //
    }
}
