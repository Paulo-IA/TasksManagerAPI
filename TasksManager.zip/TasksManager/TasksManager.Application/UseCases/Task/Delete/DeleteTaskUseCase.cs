﻿namespace TasksManager.Application.UseCases.Task.Delete;

public class DeleteTaskUseCase
{
    public void Execute(int id)
    {
        //
    }
}
