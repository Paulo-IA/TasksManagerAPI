﻿using TasksManager.Communication.Responses;

namespace TasksManager.Application.UseCases.Task.GetAll;

public class GetAllTasksUseCase
{
    public ResponseAllTaskJson Execute()
    {
        return new ResponseAllTaskJson
        {
            Tasks = new List<ResponseShortTaskJson>
            {
                new ResponseShortTaskJson
                {
                    Id = 1,
                    Title = "Teste",
                    Description = "Teste de descrição",
                    LimitDate = new DateTime(year: 2024, month: 08, day: 25),
                    Status = Communication.Enums.Status.InProgress
                },
                new ResponseShortTaskJson
                {
                    Id = 2,
                    Title = "Teste 2",
                    Description = "Teste de descrição 2",
                    LimitDate = new DateTime(year: 2024, month: 08, day: 26),
                    Status = Communication.Enums.Status.Concluded
                }
            }
        };
    }
}
