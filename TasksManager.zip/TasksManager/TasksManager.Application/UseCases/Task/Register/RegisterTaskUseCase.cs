﻿using TasksManager.Communication.Requests;
using TasksManager.Communication.Responses;

namespace TasksManager.Application.UseCases.Task.Register;

public class RegisterTaskUseCase
{
    public ResponseRegisteredTaskJson Execute(RequestTaskJson request)
    {
        return new ResponseRegisteredTaskJson
        {
            Id = 1,
            Title = request.Title,
        };
    }
}
